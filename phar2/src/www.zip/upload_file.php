<?php 
include 'function.php';
upload_file();
?>